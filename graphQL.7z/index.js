const express = require('express');
const { graphqlHTTP } = require('express-graphql');
const { buildSchema } = require('graphql');

// Construct a schema, using GraphQL schema language
const schema = buildSchema(`
  type Product{
    id:ID!
    name: String
    price: Int
    description: String
  }
  input ProductInput {
    name: String
    price: Int
    description : String
  }
  type Query {
    getProduct( id : ID! ) : Product
  }
  type Mutation {
    addProduct(input: ProductInput): Product
    updateProduct( id: ID! , input: ProductInput! ): Product
    deleteProduct( id: ID! ) : String
  }
`);

const products = [{
  id: 1,
  name: '첫번째 제품',
  price: 2000,
  description : "하하하"
},{
  id: 2,
  name: '두번째 제품',
  price: 1200,
  description : "호호호"
}]

const root = { 
  //id가 입력되고, products에서 찾아... product타입으로 id와 일치하는것 === 문자열(앞에 주어진 param id)
  getProduct : ({id}) => products.find( 
    product => product.id === parseInt(id) 
    ) ,
  addProduct :  ({input}) => {
    input.id = parseInt(products.length+1);
    products.push(input);
    return root.getProduct({id : input.id});
  },
  updateProduct :  ({ id , input}) => {
    const index = products.findIndex( product => product.id === parseInt(id) )
    products[index] = {
      id : parseInt(id) ,
      //input에 객채들이 안에 펼쳐진다
      ...input    
    }
    return products[index];
  },
  deleteProduct :  ({ id }) => {
    const index = products.findIndex( product => product.id === parseInt(id) )
    // products에서 일치하는 0번데이터부터 1개의 데이터만 지우겠다
    products.splice(index, 1);  
    return "remove success";
  }
}   

//express 시작
const app = express();
app.use('/graphql', graphqlHTTP({
  schema: schema,   //위에 query
  rootValue: root,      //위에 root
  graphiql: true,       //차후에는 false로 두어야지 그렇지 않으면 개발 정보가 모두 공개됨
}));

app.use('/static', express.static('static'));

//4000포트에 연결
app.listen(4000, () => {
  console.log('Running a GraphQL API server at localhost:4000/graphql');
}); 