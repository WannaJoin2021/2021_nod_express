const mongoose = require('mongoose');
const { Schema } = mongoose;
const moment = require('moment-timezone');

//ProductsSchema를 가져올건데 제품명, 가격, 설명 등등의 정보를 넣어줄거야 / 스키마정하기
const ProductsSchema = new Schema({
    name : {
        type : String,
        //제품명이 없으면... .꼭 넣어줘...
        required: [true, '제품명을 입력해주세요.']
    },
    price : Number ,
    description : String ,
    createdAt : {
        type : Date,
        default : Date.now()
    }
}, { collection: 'Products' });

//dateFormat안에 날짜를 넣어주면 해당 날짜를 아래의 폼에 맞춰서 출력
ProductsSchema.methods.dateFormat = function(){

    return moment(this.createdAt)
        .tz("Asia/Seoul")
        .format('MMMM Do YYYY, h:mm:ss a')

}

//맨 위에 ProductsSchema 값을 받아와서 products라는 collections 명을 넣어줘
module.exports = mongoose.model('Products' , ProductsSchema);